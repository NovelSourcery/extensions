
NovelSourceryNS@4281820d4866bb71bed3dec5224aad9cf4633d44a113682cfb0c3b1cfd71702d"@
https://novelsourcery.github.iohttps://discord.gg/JG2K2jTjd6�ڤ
�
Tsundoku: Calibre.eu.kanade.tachiyomi.novelextension.all.calibre�
nhttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-all.calibre-v1.4.1.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.all.calibre.png"1.4(21.4.1B��������?Calibreall
�
Tsundoku: ArNovel-eu.kanade.tachiyomi.novelextension.ar.arnovel�
mhttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-ar.arnovel-v1.4.4.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.ar.arnovel.png"1.4(21.4.4B*���ǁ���-ArNovelar"https://ar-no.com
�
Tsundoku: Azora+eu.kanade.tachiyomi.novelextension.ar.azora�
khttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-ar.azora-v1.4.4.apkhttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.ar.azora.png"1.4(21.4.4B,���ܷї�1Azoraar"https://azoramoon.com
�
Tsundoku: Free Kol Novel2eu.kanade.tachiyomi.novelextension.ar.freekolnovel�
rhttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-ar.freekolnovel-v1.4.2.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.ar.freekolnovel.png"1.4(21.4.2B9ܩ����ǚFree Kol Novelar"https://free.kolnovel.com
�
Tsundoku: Galaxy Novels2eu.kanade.tachiyomi.novelextension.ar.galaxynovels�
rhttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-ar.galaxynovels-v1.4.2.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.ar.galaxynovels.png"1.4(21.4.2B7����ŋ1Galaxy Novelsar"https://galaxynovels.com
�
Tsundoku: Golden Rest0eu.kanade.tachiyomi.novelextension.ar.goldenrest�
phttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-ar.goldenrest-v1.4.2.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.ar.goldenrest.png"1.4(21.4.2B0��������/Golden Restar"https://golden.rest
�
Tsundoku: HizoManga/eu.kanade.tachiyomi.novelextension.ar.hizomanga�
ohttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-ar.hizomanga-v1.4.4.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.ar.hizomanga.png"1.4(21.4.4B0×מ����-	HizoMangaar"https://hizomanga.net
�
Tsundoku: Kol Novel.eu.kanade.tachiyomi.novelextension.ar.kolnovel�
nhttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-ar.kolnovel-v1.4.2.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.ar.kolnovel.png"1.4(21.4.2B/��馿�̻;	Kol Novelar"https://kolnovel.com
�
Tsundoku: Markazriwayat3eu.kanade.tachiyomi.novelextension.ar.markazriwayat�
shttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-ar.markazriwayat-v1.4.5.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.ar.markazriwayat.png"1.4(21.4.5B8�����綁Markazriwayatar"https://markazriwayat.com
�
Tsundoku: Novel Arab/eu.kanade.tachiyomi.novelextension.ar.novelarab�
ohttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-ar.novelarab-v1.4.4.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.ar.novelarab.png"1.4(21.4.4B1���۴���
Novel Arabar"https://novelarab.com
�
Tsundoku: NovelsParadise4eu.kanade.tachiyomi.novelextension.ar.novelsparadise�
thttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-ar.novelsparadise-v1.4.2.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.ar.novelsparadise.png"1.4(21.4.2B;�����ڬXNovelsParadisear"https://novelsparadise.site
�
Tsundoku: Rewayah Fans1eu.kanade.tachiyomi.novelextension.ar.rewayahfans�
qhttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-ar.rewayahfans-v1.4.1.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.ar.rewayahfans.png"1.4(21.4.1B5�������,Rewayah Fansar"https://rewayahfans.net
�
Tsundoku: Rewayat Club1eu.kanade.tachiyomi.novelextension.ar.rewayatclub�
qhttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-ar.rewayatclub-v1.4.2.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.ar.rewayatclub.png"1.4(21.4.2B2����◔�yRewayat Clubar"https://rewayat.club
�
Tsundoku: Rewayat Fans1eu.kanade.tachiyomi.novelextension.ar.rewayatfans�
qhttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-ar.rewayatfans-v1.4.1.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.ar.rewayatfans.png"1.4(21.4.1B5����֢��tRewayat Fansar"https://rewayatfans.com
�
Tsundoku: Riwyat,eu.kanade.tachiyomi.novelextension.ar.riwyat�
lhttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-ar.riwyat-v1.4.5.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.ar.riwyat.png"1.4(21.4.5B*�����³�6Riwyatar"https://cenele.com
�
Tsundoku: SeaNovel.eu.kanade.tachiyomi.novelextension.ar.seanovel�
nhttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-ar.seanovel-v1.4.2.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.ar.seanovel.png"1.4(21.4.2B.������¯nSeaNovelar"https://seanovel.org
�
Tsundoku: Sunovels.eu.kanade.tachiyomi.novelextension.ar.sunovels�
nhttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-ar.sunovels-v1.4.1.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.ar.sunovels.png"1.4(21.4.1B.�������@Sunovelsar"https://sunovels.com
�
Tsundoku: AllNovel.eu.kanade.tachiyomi.novelextension.en.allnovel�
nhttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.allnovel-v1.4.7.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.allnovel.png"1.4(21.4.7B.�������<AllNovelen"https://allnovel.org
�
Tsundoku: AllNovelFull2eu.kanade.tachiyomi.novelextension.en.allnovelfull�
rhttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.allnovelfull-v1.4.7.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.allnovelfull.png"1.4(21.4.7B/�␚��׶-AllNovelFullen"https://novgo.net
�
Tsundoku: AsianNovel0eu.kanade.tachiyomi.novelextension.en.asiannovel�
phttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.asiannovel-v1.4.3.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.asiannovel.png"1.4(21.4.3B5��������/
AsianNovelen"https://www.asianovel.net
�
Tsundoku: BoxNovel.eu.kanade.tachiyomi.novelextension.en.boxnovel�
nhttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.boxnovel-v1.4.5.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.boxnovel.png"1.4(21.4.5B/씀��ڪ�nBoxNovelen"https://novelnice.com
�
Tsundoku: Bright Novels2eu.kanade.tachiyomi.novelextension.en.brightnovels�
rhttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.brightnovels-v1.4.4.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.brightnovels.png"1.4(21.4.4B7묝�����HBright Novelsen"https://brightnovels.com
�
Tsundoku: CitrusAurora2eu.kanade.tachiyomi.novelextension.en.citrusaurora�
rhttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.citrusaurora-v1.4.4.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.citrusaurora.png"1.4(21.4.4B6�޻��sCitrusAuroraen"https://citrusaurora.com
�
Tsundoku: Crimson Scrolls4eu.kanade.tachiyomi.novelextension.en.crimsonscrolls�
thttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.crimsonscrolls-v1.4.1.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.crimsonscrolls.png"1.4(21.4.1B;�ܧ�����)Crimson Scrollsen"https://crimsonscrolls.net
�
Tsundoku: Dao Translate2eu.kanade.tachiyomi.novelextension.en.daotranslate�
rhttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.daotranslate-v1.4.2.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.daotranslate.png"1.4(21.4.2B7ߌ������Dao Translateen"https://daotranslate.com
�
Tsundoku: Divine Dao Library6eu.kanade.tachiyomi.novelextension.en.divinedaolibrary�
vhttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.divinedaolibrary-v1.4.2.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.divinedaolibrary.png"1.4(21.4.2BD�����㋈Divine Dao Libraryen" https://www.divinedaolibrary.com
�
Tsundoku: Dragonholic1eu.kanade.tachiyomi.novelextension.en.dragonholic�
qhttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.dragonholic-v1.4.4.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.dragonholic.png"1.4(21.4.4BAҞ㶞���NDragonholicen"$https://dragonholictranslations.com/
�
Tsundoku: DragonTea/eu.kanade.tachiyomi.novelextension.en.dragontea�
ohttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.dragontea-v1.4.4.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.dragontea.png"1.4(21.4.4B0�贙���[	DragonTeaen"https://dragontea.ink
�
Tsundoku: DuskBlossoms2eu.kanade.tachiyomi.novelextension.en.duskblossoms�
rhttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.duskblossoms-v1.4.4.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.duskblossoms.png"1.4(21.4.4B6����ѳ��7DuskBlossomsen"https://duskblossoms.com
�
Tsundoku: EPUB KFCok/eu.kanade.tachiyomi.novelextension.en.epubkfcok�
ohttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.epubkfcok-v1.4.2.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.epubkfcok.png"1.4(21.4.2B5�����ڤB
EPUB KFCokall"https://fucknovelpia.com
�
Tsundoku: Eternalune0eu.kanade.tachiyomi.novelextension.en.eternalune�
phttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.eternalune-v1.4.4.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.eternalune.png"1.4(21.4.4B2��������<
Eternaluneen"https://eternalune.com
�
Tsundoku: EtudeTranslations7eu.kanade.tachiyomi.novelextension.en.etudetranslations�
whttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.etudetranslations-v1.4.4.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.etudetranslations.png"1.4(21.4.4B@��������
EtudeTranslationsen"https://etudetranslations.com
�
Tsundoku: Fans MTL-eu.kanade.tachiyomi.novelextension.en.fansmtl�
mhttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.fansmtl-v1.4.4.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.fansmtl.png"1.4(21.4.4B0��������yFans MTLen"https://www.fanmtl.com
�
Tsundoku: Fans Translations6eu.kanade.tachiyomi.novelextension.en.fanstranslations�
vhttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.fanstranslations-v1.4.4.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.fanstranslations.png"1.4(21.4.4B?���Ԫᓶ.Fans Translationsen"https://fanstranslations.com
�
Tsundoku: Fenrirealm0eu.kanade.tachiyomi.novelextension.en.fenrirealm�
phttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.fenrirealm-v1.4.6.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.fenrirealm.png"1.4(21.4.6B2�����	
Fenrirealmen"https://fenrirealm.com
�
Tsundoku: Fiction Zone1eu.kanade.tachiyomi.novelextension.en.fictionzone�
qhttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.fictionzone-v1.4.4.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.fictionzone.png"1.4(21.4.4B5�ɧ��ٜ/Fiction Zoneen"https://fictionzone.net
�
Tsundoku: Foxaholic/eu.kanade.tachiyomi.novelextension.en.foxaholic�
ohttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.foxaholic-v1.4.4.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.foxaholic.png"1.4(21.4.4B4��Ԑ����	Foxaholicen"https://www.foxaholic.com
�
Tsundoku: Foxaholic 18+1eu.kanade.tachiyomi.novelextension.en.foxaholic18�
qhttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.foxaholic18-v1.4.4.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.foxaholic18.png"1.4(21.4.48B7�����ڡ�Foxaholic 18+en"https://18.foxaholic.com
�
Tsundoku: FreeWebNovel2eu.kanade.tachiyomi.novelextension.en.freewebnovel�
rhttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.freewebnovel-v1.4.7.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.freewebnovel.png"1.4(21.4.7B6�ߴ��ڜ�7FreeWebNovelen"https://freewebnovel.com
�
Tsundoku: Hiraeth Translation9eu.kanade.tachiyomi.novelextension.en.hireaththranslation�
yhttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.hireaththranslation-v1.4.4.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.hireaththranslation.png"1.4(21.4.4BC��������\Hiraeth Translationen"https://hiraethtranslation.com
�
Tsundoku: Honeyfeed/eu.kanade.tachiyomi.novelextension.en.honeyfeed�
ohttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.honeyfeed-v1.4.2.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.honeyfeed.png"1.4(21.4.2B3ܝߪЍ��	Honeyfeeden"https://www.honeyfeed.fm
�
Tsundoku: Inkitt,eu.kanade.tachiyomi.novelextension.en.inkitt�
lhttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.inkitt-v1.4.2.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.inkitt.png"1.4(21.4.2B.�Ŋ�ݠ��IInkitten"https://www.inkitt.com
�
Tsundoku: Ippo Translation5eu.kanade.tachiyomi.novelextension.en.ippotranslation�
uhttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.ippotranslation-v1.4.2.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.ippotranslation.png"1.4(21.4.2B>���Ɂ㴻8Ippo Translationen"https://ippotranslations.com
�
Tsundoku: KDT Novels/eu.kanade.tachiyomi.novelextension.en.kdtnovels�
ohttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.kdtnovels-v1.4.2.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.kdtnovels.png"1.4(21.4.2B1�ܟź���!
KDT Novelsen"https://kdtnovels.net
�
Tsundoku: KnoxT+eu.kanade.tachiyomi.novelextension.en.knoxt�
khttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.knoxt-v1.4.2.apkhttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.knoxt.png"1.4(21.4.2B*Ɇ������KnoxTen"https://knoxt.space
�
Tsundoku: Konkon,eu.kanade.tachiyomi.novelextension.en.konkon�
lhttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.konkon-v1.4.2.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.konkon.png"1.4(21.4.28B*�З޼���
Konkonen"https://konkon.ink
�
Tsundoku: KuuPress.eu.kanade.tachiyomi.novelextension.en.kuupress�
nhttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.kuupress-v1.4.5.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.kuupress.png"1.4(21.4.5B.�������� KuuPressen"https://kuupress.com
�
Tsundoku: LazyGirlTranslations:eu.kanade.tachiyomi.novelextension.en.lazygirltranslations�
zhttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.lazygirltranslations-v1.4.2.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.lazygirltranslations.png"1.4(21.4.2BEє����LazyGirlTranslationsen" https://lazygirltranslations.com
�
Tsundoku: LibRead-eu.kanade.tachiyomi.novelextension.en.libread�
mhttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.libread-v1.4.7.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.libread.png"1.4(21.4.7B,�������LibReaden"https://libread.com
�
Tsundoku: LightNovelHeaven6eu.kanade.tachiyomi.novelextension.en.lightnovelheaven�
vhttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.lightnovelheaven-v1.4.4.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.lightnovelheaven.png"1.4(21.4.4B>۩������LightNovelHeavenen"https://lightnovelheaven.com
�
Tsundoku: LightNovelPlus4eu.kanade.tachiyomi.novelextension.en.lightnovelplus�
thttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.lightnovelplus-v1.4.6.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.lightnovelplus.png"1.4(21.4.6B:����л��.LightNovelPlusen"https://lightnovelplus.com
�
"Tsundoku: Light Novel Translations;eu.kanade.tachiyomi.novelextension.en.lightnoveltranslation�
{https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.lightnoveltranslation-v1.4.2.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.lightnoveltranslation.png"1.4(21.4.2BM����λ��dLight Novel Translationsen"#https://lightnovelstranslations.com
�
Tsundoku: Light Novel World5eu.kanade.tachiyomi.novelextension.en.lightnovelworld�
uhttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.lightnovelworld-v1.4.2.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.lightnovelworld.png"1.4(21.4.2B>��������Light Novel Worlden"https://lightnovelworld.org
�
Tsundoku: LnCrawler/eu.kanade.tachiyomi.novelextension.en.lncrawler�
ohttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.lncrawler-v1.4.3.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.lncrawler.png"1.4(21.4.3B5�������=	LnCrawlerall"https://lncrawler.monster
�
Tsundoku: Lnori+eu.kanade.tachiyomi.novelextension.en.lnori�
khttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.lnori-v1.4.4.apkhttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.lnori.png"1.4(21.4.4B)���ײ�
Lnoriall"https://lnori.com
�
Tsundoku: LulloBox.eu.kanade.tachiyomi.novelextension.en.lullobox�
nhttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.lullobox-v1.4.4.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.lullobox.png"1.4(21.4.4B.��ӡ���LulloBoxen"https://lullobox.com
�
Tsundoku: MtlBooks.eu.kanade.tachiyomi.novelextension.en.mtlbooks�
nhttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.mtlbooks-v1.4.4.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.mtlbooks.png"1.4(21.4.4B.ӳ���ҷ�.MtlBooksen"https://mtlbooks.com
�
Tsundoku: MTL Reader/eu.kanade.tachiyomi.novelextension.en.mtlreader�
ohttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.mtlreader-v1.4.1.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.mtlreader.png"1.4(21.4.1B1������3
MTL Readeren"https://mtlreader.com
�
Tsundoku: MTL Wuxia.eu.kanade.tachiyomi.novelextension.en.mtlwuxia�
nhttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.mtlwuxia-v1.4.1.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.mtlwuxia.png"1.4(21.4.1B/ڶ��Є��|	MTL Wuxiaen"https://mtlwuxia.com
�
Tsundoku: MVLEMPYR.eu.kanade.tachiyomi.novelextension.en.mvlempyr�
nhttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.mvlempyr-v1.4.1.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.mvlempyr.png"1.4(21.4.1B1̡����׸MVLEMPYRen"https://www.mvlempyr.io
�
Tsundoku: MZ Novels.eu.kanade.tachiyomi.novelextension.en.mznovels�
nhttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.mznovels-v1.4.2.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.mznovels.png"1.4(21.4.2B/������֒1	MZ Novelsen"https://mznovels.com
�
Tsundoku: NeoSekai Translations.eu.kanade.tachiyomi.novelextension.en.neosekai�
nhttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.neosekai-v1.4.4.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.neosekai.png"1.4(21.4.4BK�매��Ҧ>NeoSekai Translationsen"$https://www.neosekaitranslations.com
�
Tsundoku: NoiceTranslations7eu.kanade.tachiyomi.novelextension.en.noicetranslations�
whttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.noicetranslations-v1.4.4.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.noicetranslations.png"1.4(21.4.4B@�����ʃ�dNoiceTranslationsen"https://noicetranslations.com
�
Tsundoku: Novelable/eu.kanade.tachiyomi.novelextension.en.novelable�
ohttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.novelable-v1.4.2.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.novelable.png"1.4(21.4.2B0�Ù뀶��l	Novelableen"https://novelable.com
�
Tsundoku: NovelBin.eu.kanade.tachiyomi.novelextension.en.novelbin�
nhttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.novelbin-v1.4.7.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.novelbin.png"1.4(21.4.7B.�趬�牅NovelBinen"https://novelbin.com
�
Tsundoku: NovelBuddy0eu.kanade.tachiyomi.novelextension.en.novelbuddy�
phttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.novelbuddy-v1.4.3.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.novelbuddy.png"1.4(21.4.3B1����
NovelBuddyen"https://novelbuddy.io
�
Tsundoku: NovelCool/eu.kanade.tachiyomi.novelextension.en.novelcool�
ohttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.novelcool-v1.4.2.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.novelcool.png"1.4(21.4.2B0���Įᙇi	NovelCoolen"https://novelcool.com
�
Tsundoku: NovelDex.eu.kanade.tachiyomi.novelextension.en.noveldex�
nhttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.noveldex-v1.4.3.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.noveldex.png"1.4(21.4.38B-Ƅ������hNovelDexen"https://noveldex.io
�
Tsundoku: Novel Fire/eu.kanade.tachiyomi.novelextension.en.novelfire�
ohttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.novelfire-v1.4.7.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.novelfire.png"1.4(21.4.7B0���ÇǸc	NovelFireen"https://novelfire.net
�
Tsundoku: NovelFull/eu.kanade.tachiyomi.novelextension.en.novelfull�
ohttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.novelfull-v1.4.6.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.novelfull.png"1.4(21.4.6B0������	NovelFullen"https://novelfull.com
�
Tsundoku: NovelHall/eu.kanade.tachiyomi.novelextension.en.novelhall�
ohttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.novelhall-v1.4.4.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.novelhall.png"1.4(21.4.4B0�ͼ�����s	NovelHallen"https://novelhall.com
�
Tsundoku: NovelHi-eu.kanade.tachiyomi.novelextension.en.novelhi�
mhttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.novelhi-v1.4.1.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.novelhi.png"1.4(21.4.1B,������{NovelHien"https://novelhi.com
�
Tsundoku: NovelHub.eu.kanade.tachiyomi.novelextension.en.novelhub�
nhttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.novelhub-v1.4.3.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.novelhub.png"1.4(21.4.3B.�����Ԑ�NovelHuben"https://novelhub.net
�
Tsundoku: NovelLib-eu.kanade.tachiyomi.novelextension.en.novelib�
mhttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.novelib-v1.4.3.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.novelib.png"1.4(21.4.3B-ڻ������&NovelLiben"https://novelib.com
�
Tsundoku: Novelight/eu.kanade.tachiyomi.novelextension.en.novelight�
ohttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.novelight-v1.4.1.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.novelight.png"1.4(21.4.1B0�Ԑ�����B	Novelighten"https://novelight.net
�
Tsundoku: NovelLib.eu.kanade.tachiyomi.novelextension.en.novellib�
nhttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.novellib-v1.4.1.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.novellib.png"1.4(21.4.1B5ڻ������&NovelLiben"https://www.novellib.online
�
Tsundoku: NovelLive/eu.kanade.tachiyomi.novelextension.en.novellive�
ohttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.novellive-v1.4.5.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.novellive.png"1.4(21.4.5B0�����ߨ�	NovelLiveen"https://novellive.app
�
Tsundoku: NovelMultiverse5eu.kanade.tachiyomi.novelextension.en.novelmultiverse�
uhttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.novelmultiverse-v1.4.4.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.novelmultiverse.png"1.4(21.4.4B<�������fNovelMultiverseen"https://novelmultiverse.com
�
Tsundoku: NovelNinja0eu.kanade.tachiyomi.novelextension.en.novelninja�
phttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.novelninja-v1.4.4.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.novelninja.png"1.4(21.4.4B2��������&
NovelNinjaen"https://novelninja.xyz
�
Tsundoku: Novels Knight2eu.kanade.tachiyomi.novelextension.en.novelsknight�
rhttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.novelsknight-v1.4.3.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.novelsknight.png"1.4(21.4.3BE�����ĉmNovels Knighten"&https://novelsknight.punchmanga.online
�
Tsundoku: Novel Updates2eu.kanade.tachiyomi.novelextension.en.novelupdates�
rhttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.novelupdates-v1.4.5.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.novelupdates.png"1.4(21.4.5B;��⌉�ՕWNovel Updatesen"https://www.novelupdates.com
�
Tsundoku: PastelTales1eu.kanade.tachiyomi.novelextension.en.pasteltales�
qhttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.pasteltales-v1.4.4.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.pasteltales.png"1.4(21.4.4B4��������?PastelTalesen"https://pasteltales.com
�
Tsundoku: PawRead-eu.kanade.tachiyomi.novelextension.en.pawread�
mhttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.pawread-v1.4.1.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.pawread.png"1.4(21.4.1B.�Ƕ�����uPawReaden"https://m.pawread.com
�
Tsundoku: PenguinSquad2eu.kanade.tachiyomi.novelextension.en.penguinsquad�
rhttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.penguinsquad-v1.4.3.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.penguinsquad.png"1.4(21.4.3B7�������PenguinSquaden"https://penguin-squad.com
�
Tsundoku: Ranobes-eu.kanade.tachiyomi.novelextension.en.ranobes�
mhttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.ranobes-v1.4.2.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.ranobes.png"1.4(21.4.2B,�Ҋ��֗�nRanobesen"https://ranobes.net
�
Tsundoku: Ranovel-eu.kanade.tachiyomi.novelextension.en.ranovel�
mhttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.ranovel-v1.4.4.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.ranovel.png"1.4(21.4.4B,��ϟ����	Ranovelen"https://ranovel.com
�
Tsundoku: ReadFromNet1eu.kanade.tachiyomi.novelextension.en.readfromnet�
qhttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.readfromnet-v1.4.2.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.readfromnet.png"1.4(21.4.2B1���䜈��ReadFromNeten"https://readfrom.net
�
Tsundoku: ReadNovelFull3eu.kanade.tachiyomi.novelextension.en.readnovelfull�
shttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.readnovelfull-v1.4.6.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.readnovelfull.png"1.4(21.4.6B8�֦�����#ReadNovelFullen"https://readnovelfull.com
�
Tsundoku: ReadNovelMtl2eu.kanade.tachiyomi.novelextension.en.readnovelmtl�
rhttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.readnovelmtl-v1.4.2.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.readnovelmtl.png"1.4(21.4.2B6�˰���îuReadNovelMtlen"https://readnovelmtl.com
�
Tsundoku: Requiem Translations9eu.kanade.tachiyomi.novelextension.en.requiemtranslations�
yhttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.requiemtranslations-v1.4.2.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.requiemtranslations.png"1.4(21.4.2B<�㶎����:Requiem Translationsen"https://requiemtls.com
�
Tsundoku: Royal Road/eu.kanade.tachiyomi.novelextension.en.royalroad�
ohttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.royalroad-v1.4.3.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.royalroad.png"1.4(21.4.3B5������هa
Royal Roaden"https://www.royalroad.com
�
Tsundoku: Scribble Hub1eu.kanade.tachiyomi.novelextension.en.scribblehub�
qhttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.scribblehub-v1.4.3.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.scribblehub.png"1.4(21.4.3B9���ڡ���MScribble Huben"https://www.scribblehub.com
�
Tsundoku: Shanghai Fantasy5eu.kanade.tachiyomi.novelextension.en.shanghaifantasy�
uhttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.shanghaifantasy-v1.4.3.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.shanghaifantasy.png"1.4(21.4.3B=�ȳ΃���nShanghai Fantasyen"https://shanghaifantasy.com
�
Tsundoku: SleepyTranslations8eu.kanade.tachiyomi.novelextension.en.sleepytranslations�
xhttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.sleepytranslations-v1.4.4.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.sleepytranslations.png"1.4(21.4.4BBЌ������:SleepyTranslationsen"https://sleepytranslations.com
�
Tsundoku: Sonic MTL.eu.kanade.tachiyomi.novelextension.en.sonicmtl�
nhttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.sonicmtl-v1.4.4.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.sonicmtl.png"1.4(21.4.4B3���̙)	Sonic MTLen"https://www.sonicmtl.com
�
Tsundoku: Srank Manga0eu.kanade.tachiyomi.novelextension.en.srankmanga�
phttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.srankmanga-v1.4.4.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.srankmanga.png"1.4(21.4.4B3����ⱡ�pSrank Mangaen"https://srankmanga.com
�
Tsundoku: StorySeedling3eu.kanade.tachiyomi.novelextension.en.storyseedling�
shttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.storyseedling-v1.4.1.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.storyseedling.png"1.4(21.4.1B8��ͦ௿�StorySeedlingen"https://storyseedling.com
�
Tsundoku: Sufficient Velocity8eu.kanade.tachiyomi.novelextension.en.sufficientvelocity�
xhttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.sufficientvelocity-v1.4.2.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.sufficientvelocity.png"1.4(21.4.2BJ����ɠ��pSufficient Velocityen"%https://forums.sufficientvelocity.com
�
Tsundoku: System Translation7eu.kanade.tachiyomi.novelextension.en.systemtranslation�
whttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.systemtranslation-v1.4.2.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.systemtranslation.png"1.4(21.4.2BA�����֣System Translationen"https://systemtranslation.com
�
Tsundoku: TomatoMTL/eu.kanade.tachiyomi.novelextension.en.tomatomtl�
ohttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.tomatomtl-v1.4.4.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.tomatomtl.png"1.4(21.4.4B0�����ғ�$	TomatoMTLen"https://tomatomtl.com
�
Tsundoku: Translatin Otaku1eu.kanade.tachiyomi.novelextension.en.translatino�
qhttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.translatino-v1.4.5.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.translatino.png"1.4(21.4.5B=��镏�Ԕ:Translatin Otakuen"https://translatinotaku.net
�
Tsundoku: TranslationWeaver1eu.kanade.tachiyomi.novelextension.en.transweaver�
qhttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.transweaver-v1.4.2.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.transweaver.png"1.4(21.4.2B:��θ���TranslationWeaveren"https://transweaver.com
�
Tsundoku: UniversalNovel4eu.kanade.tachiyomi.novelextension.en.universalnovel�
thttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.universalnovel-v1.4.2.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.universalnovel.png"1.4(21.4.2B:����塁�ZUniversalNovelen"https://universalnovel.com
�
Tsundoku: Vynovel-eu.kanade.tachiyomi.novelextension.en.vynovel�
mhttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.vynovel-v1.4.2.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.vynovel.png"1.4(21.4.2B,��Ѕ����AVynovelen"https://vynovel.com
�
Tsundoku: Wattpad-eu.kanade.tachiyomi.novelextension.en.wattpad�
mhttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.wattpad-v1.4.2.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.wattpad.png"1.4(21.4.2B0���Ԉ���?Wattpaden"https://www.wattpad.com
�
Tsundoku: WebNovel.eu.kanade.tachiyomi.novelextension.en.webnovel�
nhttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.webnovel-v1.4.3.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.webnovel.png"1.4(21.4.3B9�ä���-Webnovel Novelsen"https://www.webnovel.com
�
Tsundoku: WebNovel Translation9eu.kanade.tachiyomi.novelextension.en.webnoveltranslation�
yhttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.webnoveltranslation-v1.4.4.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.webnoveltranslation.png"1.4(21.4.4BF��߈���XWebNovel Translationen" https://webnoveltranslations.com
�
Tsundoku: WordExcerpt1eu.kanade.tachiyomi.novelextension.en.wordexcerpt�
qhttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.wordexcerpt-v1.4.2.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.wordexcerpt.png"1.4(21.4.2B4�������`WordExcerpten"https://wordexcerpt.com
�
Tsundoku: WTR-LAB,eu.kanade.tachiyomi.novelextension.en.wtrlab�
lhttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.wtrlab-v1.4.6.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.wtrlab.png"1.4(21.4.6B,�������WTR-LABen"https://wtr-lab.com
�
Tsundoku: Wuxiabox.eu.kanade.tachiyomi.novelextension.en.wuxiabox�
nhttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.wuxiabox-v1.4.4.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.wuxiabox.png"1.4(21.4.4B.����ɬ��Wuxiaboxen"https://wuxiabox.com
�
Tsundoku: WuxiaClick0eu.kanade.tachiyomi.novelextension.en.wuxiaclick�
phttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.wuxiaclick-v1.4.4.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.wuxiaclick.png"1.4(21.4.4B0�������7
WuxiaClickall"https://wuxia.click
�
Tsundoku: Wuxia Space0eu.kanade.tachiyomi.novelextension.en.wuxiaspace�
phttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.wuxiaspace-v1.4.4.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.wuxiaspace.png"1.4(21.4.4B6��������QWuxia Spaceen"https://www.wuxiaspot.com
�
Tsundoku: WuxiaWorld.Site4eu.kanade.tachiyomi.novelextension.en.wuxiaworldsite�
thttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.wuxiaworldsite-v1.4.4.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.wuxiaworldsite.png"1.4(21.4.4B8�ě�����OWuxiaWorld.Siteen"https://wuxiaworld.site
�
Tsundoku: Zetro Translation6eu.kanade.tachiyomi.novelextension.en.zetrotranslation�
vhttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-en.zetrotranslation-v1.4.6.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.en.zetrotranslation.png"1.4(21.4.6B?�核˪��(Zetro Translationen"https://zetrotranslation.com
�
Tsundoku: PanchoTranslations8eu.kanade.tachiyomi.novelextension.es.panchotranslations�
xhttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-es.panchotranslations-v1.4.4.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.es.panchotranslations.png"1.4(21.4.4B?����ߟ��[PanchoTranslationses"https://panchonovels.online
�
Tsundoku: TCandSega,eu.kanade.tachiyomi.novelextension.es.tcsega�
lhttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-es.tcsega-v1.4.2.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.es.tcsega.png"1.4(21.4.2B<��������	TCandSegaes"!https://teamchmantranslations.com
�
Tsundoku: LightNovelFR2eu.kanade.tachiyomi.novelextension.fr.lightnovelfr�
rhttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-fr.lightnovelfr-v1.4.2.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.fr.lightnovelfr.png"1.4(21.4.2B6������ȅLightNovelFRfr"https://lightnovelfr.com
�
Tsundoku: MassNovel/eu.kanade.tachiyomi.novelextension.fr.massnovel�
ohttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-fr.massnovel-v1.4.4.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.fr.massnovel.png"1.4(21.4.4B/ۓ���ɫ�s	MassNovelfr"https://massnovel.fr
�
Tsundoku: WorldNovel0eu.kanade.tachiyomi.novelextension.fr.worldnovel�
phttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-fr.worldnovel-v1.4.4.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.fr.worldnovel.png"1.4(21.4.4B2��������
WorldNovelfr"https://world-novel.fr
�
Tsundoku: BacaLightNovel4eu.kanade.tachiyomi.novelextension.id.bacalightnovel�
thttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-id.bacalightnovel-v1.4.2.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.id.bacalightnovel.png"1.4(21.4.2B9�ٍڨ���MBacaLightNovelid"https://bacalightnovel.co
�
Tsundoku: MeioNovel/eu.kanade.tachiyomi.novelextension.id.meionovel�
ohttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-id.meionovel-v1.4.4.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.id.meionovel.png"1.4(21.4.4B1��������	MeioNovelid"https://meionovels.com
�
Tsundoku: NovelBookID1eu.kanade.tachiyomi.novelextension.id.novelbookid�
qhttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-id.novelbookid-v1.4.4.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.id.novelbookid.png"1.4(21.4.4B5�Ɖ�����9NovelBookIDid"https://www.novelbook.id
�
Tsundoku: SekteNovel0eu.kanade.tachiyomi.novelextension.id.sektenovel�
phttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-id.sektenovel-v1.4.2.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.id.sektenovel.png"1.4(21.4.2B5�殞��Ԝh
SekteNovelid"https://sektenovel.web.id
�
Tsundoku: Vanovel-eu.kanade.tachiyomi.novelextension.id.vanovel�
mhttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-id.vanovel-v1.4.4.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.id.vanovel.png"1.4(21.4.4B,��������8Vanovelid"https://vanovel.com
�
Tsundoku: WBNovel-eu.kanade.tachiyomi.novelextension.id.wbnovel�
mhttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-id.wbnovel-v1.4.4.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.id.wbnovel.png"1.4(21.4.4B,�ς�Ȃ��JWBNovelid"https://wbnovel.com
�
Tsundoku: FortuneEternal4eu.kanade.tachiyomi.novelextension.ko.fortuneeternal�
thttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-ko.fortuneeternal-v1.4.4.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.ko.fortuneeternal.png"1.4(21.4.4B>�ȍ�к��dFortuneEternalko"https://www.fortuneeternal.com
�
Tsundoku: CentralNovel2eu.kanade.tachiyomi.novelextension.pt.centralnovel�
rhttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-pt.centralnovel-v1.4.2.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.pt.centralnovel.png"1.4(21.4.2B6����ICentralNovelpt"https://centralnovel.com
�
Tsundoku: NovelLucky0eu.kanade.tachiyomi.novelextension.th.novellucky�
phttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-th.novellucky-v1.4.4.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.th.novellucky.png"1.4(21.4.4B3��������t
NovelLuckyth"https://novel-lucky.com
�
Tsundoku: EKitaplar/eu.kanade.tachiyomi.novelextension.tr.ekitaplar�
ohttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-tr.ekitaplar-v1.4.4.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.tr.ekitaplar.png"1.4(21.4.4B1��򨿡��^	EKitaplartr"https://e-kitaplar.com
�
Tsundoku: KodeksLibrary3eu.kanade.tachiyomi.novelextension.tr.kodekslibrary�
shttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-tr.kodekslibrary-v1.4.2.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.tr.kodekslibrary.png"1.4(21.4.2B<�ˈʿ���KodeksLibrarytr"https://www.kodekslibrary.com
�
Tsundoku: Namevt,eu.kanade.tachiyomi.novelextension.tr.namevt�
lhttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-tr.namevt-v1.4.2.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.tr.namevt.png"1.4(21.4.2B*��������RNamevttr"https://namevt.com
�
Tsundoku: NovelTR-eu.kanade.tachiyomi.novelextension.tr.noveltr�
mhttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-tr.noveltr-v1.4.2.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.tr.noveltr.png"1.4(21.4.2B,���ǓNovelTRtr"https://noveltr.com
�
Tsundoku: RagnarScans1eu.kanade.tachiyomi.novelextension.tr.ragnarscans�
qhttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-tr.ragnarscans-v1.4.4.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.tr.ragnarscans.png"1.4(21.4.4B4��������VRagnarScanstr"https://ragnarscans.com
�
Tsundoku: TurkceLightNovels7eu.kanade.tachiyomi.novelextension.tr.turkcelightnovels�
whttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-tr.turkcelightnovels-v1.4.4.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.tr.turkcelightnovels.png"1.4(21.4.4B@�����׍�ATurkceLightNovelstr"https://turkcelightnovels.com
�
Tsundoku: WebNovelOku1eu.kanade.tachiyomi.novelextension.tr.webnoveloku�
qhttps://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/apk/tsundoku-tr.webnoveloku-v1.4.4.apk�https://raw.githubusercontent.com/novelsourcery/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.novelextension.tr.webnoveloku.png"1.4(21.4.4B8�餠��ƖnWebNovelOkutr"https://www.webnoveloku.com